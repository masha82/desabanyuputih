
<?php $__env->startPush('css'); ?>
    
    <link rel="stylesheet" href="<?php echo e(asset('assets/demos/blog/blog.css')); ?>" type="text/css"/>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/colors.php?color=F39887')); ?>" type="text/css"/>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('title'); ?>
    <title>KORPRI KABUPATEN SITUBONDO</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section id="slider" class="slider-element min-vh-md-75 py-4 include-header">
        <div class="slider-inner">
            <div class="vertical-middle slider-element-fade">
                <div class="container text-center py-0">
                    <div class="emphasis-title mb-0">
                        <h4 class="text-uppercase ls3 fw-bolder mb-0">Selamat Datang di Website Kami</h4>
                        <h1>
                            <span id="oc-images" class="owl-carousel image-carousel carousel-widget" data-items="1"
                                  data-margin="0" data-autoplay="3000" data-loop="true" data-nav="false"
                                  data-pagi="false"
                                  data-animate-in="fadeInUp">
                                <div class="fw-bold" style="color:#AA9B4E">KORPRI</div>
                                <div class="fw-bold" style="color:#AA9B4E">KABUPATEN</div>
                                <div class="fw-bold" style="color:#AA9B4E">SITUBONDO</div>
                            </span>
                        </h1>
                    </div>

                    <div class="mx-auto" style="max-width: 600px">
                        <p class="lead fw-normal text-dark mb-0">Korps Pegawai Republik Indonesia atau biasa dikenal
                            KORPRI
                            berdiri berdasarkan Keputusan Presiden Nomor 82 Tahun 1971, 29 November 1971. </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="container">

        <div class="row border-between">
            <?php if(!empty($berita->first()->file)): ?>
                <div class="col-lg-8 mb-5 mb-lg-0">
                    <article class="entry border-bottom-0 mb-0">
                        <div class="entry-image">
                            <a href="demo-blog-single.html"><img src="<?php echo e(asset('gambar/' . $berita->first()->file)); ?>"
                                                                 alt="Image 3"></a>
                        </div>
                        <div class="entry-title">
                            <h3><a href="<?php echo e(route('news.show', $berita->first()->id)); ?>"
                                   class="stretched-link color-underline"><span><?php echo e($berita->first()->judul); ?></span></a>
                            </h3>
                        </div>
                        <div class="entry-meta">
                            <ul>
                                <li><a
                                        href="#"><?php echo e(\Carbon\Carbon::parse($berita->first()->created_at)->isoFormat('dddd, D MMMM Y')); ?></a>
                                </li>
                            </ul>
                        </div>
                        <div class="entry-content">
                            <?php echo $berita->first()->isi; ?>

                        </div>
                    </article>
                </div>
            <?php endif; ?>
            <div class="col-lg-4">
                <h3 class="font-secondary fw-medium mb-4 h4">Berita Terbaru</h3>
                <div class="row posts-md col-mb-30">
                    <?php $__currentLoopData = $berita->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="entry col-12">
                            <div class="grid-inner row gutter-20">
                                <div class="col-md-4">
                                    <a class="entry-image" href="#"><img src="<?php echo e(asset('gambar/' . $item->file)); ?>"
                                                                         alt="Image"></a>
                                </div>
                                <div class="col-md-8">
                                    <div class="entry-title title-xs">
                                        
                                        <h3><a href="<?php echo e(route('news.show', $item->id)); ?>"
                                               class="stretched-link color-underline"><?php echo e($item->judul); ?></a></h3>
                                    </div>
                                    <div class="entry-meta">
                                        <ul>
                                            <li><a
                                                    href="#"><?php echo e(\Carbon\Carbon::parse($item->created_at)->isoFormat('dddd, D MMMM Y')); ?></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

            </div>
            <a href="<?php echo e(route('news.index')); ?>" class="btn btn-sm btn-outline-secondary">Berita lainnya <i
                    class="icon-line-arrow-right"></i></a>
        </div>
    </div>
    <div class="section">
        <div class="container">
            <div class="d-flex justify-content-between">
                <h3 class="font-secondary fw-medium m-0">Galeri</h3>
                <a href="<?php echo e(route('gallery.index')); ?>" class="btn btn-sm btn-outline-secondary">Lihat lebih banyak <i
                        class="icon-line-arrow-right"></i></a>
            </div>
            <hr class="text-dark">
            <div class="row posts-md col-mb-30">
                <div class="masonry-thumbs grid-container grid-4 has-init-isotope" data-big="3" data-lightbox="gallery"
                     style="position: relative; height: 295.664px;">
                    <?php $__currentLoopData = $galeri->take(8); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!empty($item->file)): ?>
                            <a class="grid-item" href="<?php echo e(asset('galeri/' . $item->file)); ?>"
                               data-lightbox="gallery-item"
                               style="position: absolute; left: 0%; top: 0px;">
                                <div class="grid-inner">
                                    <img src="<?php echo e(asset('galeri/' . $item->file)); ?>" alt="Gallery">
                                    <div class="bg-overlay">
                                        <div class="bg-overlay-content dark">
                                            <i class="icon-line-plus h4 mb-0 animated fadeOut"
                                               data-hover-animate="fadeIn"
                                               style="animation-duration: 600ms;"></i>
                                        </div>
                                        <div class="bg-overlay-bg dark animated fadeOut" data-hover-animate="fadeIn"
                                             style="animation-duration: 600ms;"></div>
                                    </div>
                                </div>
                            </a>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\korpristb\resources\views/welcome.blade.php ENDPATH**/ ?>