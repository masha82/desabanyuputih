
<?php $__env->startPush('css'); ?>
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.1/dist/sweetalert2.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(url('https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap5.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('title'); ?>
    <title>Form Regulasi/Dasar Hukum</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section id="content">
        <div class="content-wrap">
            <div class="container clearfix">
                <div class="row">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="col-lg-6">
                        <form class="row" action="<?php echo e(route('hukum.store')); ?>" method="post"
                              enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('POST'); ?>
                            <div class="col-12 form-group">
                                <label>Judul Regulasi:</label>
                                <input type="text" name="judul" id="judul" class="form-control">
                            </div>
                            <div class="col-12 form-group">
                                <label>Nomor Regulasi:</label>
                                <input type="text" name="nomor" id="nomor" class="form-control">
                            </div>
                            <div class="col-12 form-group">
                                <label>Tahun Regulasi:</label>
                                <input type="text" name="tahun" id="tahun" class="form-control">
                            </div>
                            <div class="col-12 form-group">
                                <label>Jenis Regulasi:</label>
                                <input type="text" name="jenis" id="jenis" class="form-control">
                            </div>
                            <div class="col-12 form-group">
                                <label class="form-label">Upload Dokumen:</label>
                                <input type="file" class="form-control" name="dokumen" id="dokumen"/>
                            </div>
                            <div class="col-12 form-group">
                                <label>Status:</label>
                                <select class="form-control" name="status" id="status">
                                    <option><label>-- Pilih Salah Satu --</label></option>
                                    <option value="1">Draft</option>
                                    <option value="2">Publish</option>
                                </select>
                            </div>
                            <div class="col-12">
                                <button class="btn btn-primary" type="submit">Simpan</button>
                            </div>
                        </form>
                    </div>

                </div>
                <div class="row">
                    <h6 class="text-center">Daftar Berita</h6>
                    <div>
                        <table class="table table-striped" id="myTable">
                            <thead>
                            <tr>
                                <th>JUDUL REGULASI</th>
                                <th>NOMOR</th>
                                <th>TAHUN</th>
                                <th>JENIS</th>
                                <th>Aksi</th>
                            </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(url('https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(url('https://cdn.datatables.net/1.13.1/js/dataTables.bootstrap5.min.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.1/dist/sweetalert2.all.min.js"></script>
    <script>
        $(document).ready(function () {
            var table = $('#myTable').DataTable({
                processing: true,
                serverSide: true,
                ajax: "<?php echo e(route('regulasi.data')); ?>",
                columns: [{
                    data: 'judul',
                    name: 'judul'
                },
                    {
                        data: 'nomor',
                        name: 'nomor'
                    },
                    {
                        data: 'tahun',
                        name: 'tahun'
                    },
                    {
                        data: 'jenis',
                        name: 'jenis'
                    },
                    {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false
                    },
                ]
            });
            var del = function (id) {
                Swal.fire({
                    title: 'Apakah anda yakin?',
                    text: "Data yang sudah terhapus tidak bisa dikembalikan lagi!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: "<?php echo e(route('regulasi.index')); ?>/" + id,
                            method: "DELETE",
                            success: function (response) {
                                table.ajax.reload();
                                Swal.fire(
                                    'Terhapus!',
                                    'File sudah dihapus',
                                    'sukses'
                                )
                            },
                            failure: function (response) {
                                swal(
                                    "Internal Error",
                                    "Oops, your note was not saved.", // had a missing comma
                                    "error"
                                )
                            }
                        });
                    }
                })
            };
            $('body').on('click', '.hapus-data', function () {
                del($(this).attr('data-id'));
            });

        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\korpristb\resources\views/formregulasi.blade.php ENDPATH**/ ?>