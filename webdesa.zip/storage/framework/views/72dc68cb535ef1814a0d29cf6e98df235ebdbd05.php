
<?php $__env->startSection('title'); ?>
    <title>PENGUMUMAN</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="container topmargin bottommargin-lg">
                <div class="mx-auto" style="max-width: 700px">
                    <h2 class="mb-2 nott center ls0 gradient-text gradient-horizon">Informasi/Pengumuman Terkait Desa Banyuputih</h2>
                </div>
            </div>
        </div>
    </div>
    <div class="container clearfix">
        <div class="row gutter-40 col-mb-80">
            <div class="postcontent col-lg-12">
                <div id="posts" class="row gutter-40 mb-0">
                    <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="entry col-12 mt-0 mb-0">
                            <div class="grid-inner row g-0">
                                <div class="col-md-4">
                                    <a class="entry-image" href="#" data-lightbox="image"><img
                                            src="<?php echo e(asset('screenshot/' . $item->thumbnail)); ?>"
                                            alt="Standard Post with Image"></a>
                                </div>
                                <div class="col-md-8 ps-md-4">
                                    <div class="entry-title title-sm">
                                        <h2><a href="#"><?php echo e($item->judul); ?></a></h2>
                                    </div>
                                    <div class="entry-meta">
                                        <ul>
                                            <li><i class="icon-calendar3"></i>
                                                <?php echo e(\Carbon\Carbon::parse($item->created_at)->isoFormat('dddd, D MMMM Y')); ?>

                                            </li>
                                            <li><i class="icon-user"></i> <?php echo e($item->sumber); ?></li>
                                            <li><i class="icon-folder-open"></i> <a
                                                    href="#"><?php echo e($item->kategori); ?></a>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="entry-content">
                                        <a href="<?php echo e(route('info.show', $item->id)); ?>"
                                           class="button button-border button-rounded">Baca selengkapnya</a>
                                    </div>
                                </div>
                            </div>
                            <hr>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="row mb-3">
                    <div class="col-12">
                        <?php echo e($info->links('layouts.paginate')); ?>

                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\desabanyuputih\resources\views/pengumuman.blade.php ENDPATH**/ ?>