

<?php $__env->startSection('title'); ?>
    <title>LAYANAN KORPRI</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="container topmargin bottommargin-lg">
                <div class="mx-auto" style="max-width: 700px">
                    <h2 class="nott center ls0 gradient-text gradient-horizon">LAYANAN KORPRI KABUPATEN SITUBONDO</h2>
                </div>
                <div class="row">
                    <?php if(!empty($layanan->file)): ?>
                        <img src="<?php echo e(asset('layanan/' . $layanan->file)); ?>" alt="FAQs" class="px-5 mt-4">
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="container topmargin bottommargin-lg">
                <div class="tabs side-tabs responsive-tabs clearfix" id="tab-4">

                    <ul class="tab-nav clearfix">
                        <?php $__currentLoopData = $jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="#tabs-<?php echo e($item->id); ?>"><?php echo e($item->nama); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>

                    <div class="tab-container">
                        <?php $__currentLoopData = $jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="tab-content clearfix" id="tabs-<?php echo e($content->id); ?>">
                                <div class="col-md-12">
                                    <h4 id="faq-1"><strong>A.</strong> Informasi</h4>
                                    <?php echo $content->informasi; ?>

                                    <div class="line"></div>
                                    <!--<h4 id="faq-1"><strong>B.</strong> Mekanisme</h4>-->
                                    <!--<?php echo $content->mekanisme; ?>-->
                                    <!--<div class="line"></div>-->
                                    <!--<h4 id="faq-1"><strong>C.</strong> Syarat</h4>-->
                                    <!--<?php echo $content->syarat; ?>-->
                                    <!--<div class="line"></div>-->
                                    <h4 id="faq-1"><strong>B.</strong> Keterangan</h4>
                                    <?php echo $content->keterangan; ?>

                                    <div class="line"></div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\desabanyuputih\resources\views/layanan.blade.php ENDPATH**/ ?>