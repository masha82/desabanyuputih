
<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(url('https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap5.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('title'); ?>
    <title>DASAR HUKUM</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="container topmargin bottommargin-lg">
                <div class="heading-block mx-auto" style="max-width: 700px">
                    <h2 class="mb-2 nott center ls0 gradient-text gradient-horizon">REGULASI YANG BERKAITAN DENGAN
                        KORPRI</h2>
                </div>
                <div>
                    <table class="table table-striped" id="myTable">
                        <thead>
                        <tr>
                            <th>JUDUL REGULASI</th>
                            <th>NOMOR</th>
                            <th>TAHUN</th>
                            <th>JENIS</th>
                            <th>UNDUH</th>
                        </tr>
                        </thead>
                        <tbody>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(url('https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(url('https://cdn.datatables.net/1.13.1/js/dataTables.bootstrap5.min.js')); ?>"></script>
    <script>
        $(document).ready(function () {
            var table = $('#myTable').DataTable({
                processing: true,
                serverSide: true,
                ajax: "<?php echo e(route('regulasi.index')); ?>",
                columns: [{
                    data: 'judul',
                    name: 'judul'
                },
                    {
                        data: 'nomor',
                        name: 'nomor'
                    },
                    {
                        data: 'tahun',
                        name: 'tahun'
                    },
                    {
                        data: 'jenis',
                        name: 'jenis'
                    },
                    {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false
                    },
                ]
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\korpristb\resources\views/regulasi.blade.php ENDPATH**/ ?>